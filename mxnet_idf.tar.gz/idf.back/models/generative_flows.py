"""
Collection of flow strategies
"""

from __future__ import print_function

from mxnet.gluon.block import HybridBlock
from mxnet.gluon import nn
from mxnet.gluon import Parameter
import mxnet as mx

from .priors import SplitPrior
from .coupling import Coupling


UNIT_TESTING = False


def space_to_depth(x):
    xs = x.shape
    # Pick off every second element
    x = x.reshape(xs[0], xs[1], xs[2] // 2, 2, xs[3] // 2, 2)
    # Transpose picked elements next to channels.
    x = x.transpose(axes=(0, 1, 3, 5, 2, 4))
    # Combine with channels.
    x = x.reshape(xs[0], xs[1] * 4, xs[2] // 2, xs[3] // 2)
    return x


def depth_to_space(x):
    xs = x.shape
    # Pick off elements from channels
    x = x.reshape(xs[0], xs[1] // 4, 2, 2, xs[2], xs[3])
    # Transpose picked elements next to HW dimensions.
    x = x.transpose(axes=(0, 1, 4, 2, 5, 3))
    # Combine with HW dimensions.
    x = x.reshape(xs[0], xs[1] // 4, xs[2] * 2, xs[3] * 2)
    return x


def int_shape(x):
    return list(map(int, x.shape))


class Flatten(HybridBlock):
    def __init__(self):
        super().__init__()
        
    def hybrid_forward(self,F, x, bs):
        return F.reshape(x, shape=(bs,-1))
        #return x.view(x.size(0), -1)


class Reshape(HybridBlock):
    def __init__(self, shape):
        super().__init__()
        self.shape = shape

    def hybrid_forward(self,F, x):
        return x.view(x.size(0), *self.shape)


class Reverse(HybridBlock):
    def __init__(self):
        super().__init__()

    def hybrid_forward(self,F, z, reverse=False):
        z = F.reverse(z, axis=1)
       # flip_idx = torch.arange(z.size(1) - 1, -1, -1).long()
       # z = z[:, flip_idx, :, :]
        return z


class Permute(HybridBlock):

    def __init__(self, n_channels):
        super().__init__()

        permutation = mx.nd.arange(n_channels, dtype='int')
        permutation = mx.nd.random.shuffle(permutation)

        permutation_inv = mx.nd.zeros(n_channels, dtype='int')
        permutation_inv[permutation] = mx.nd.arange(n_channels, dtype='int')

        
        self.permutation = permutation #torch.from_numpy(permutation)
        self.permutation_inv = permutation_inv#torch.from_numpy(permutation_inv)

    def hybrid_forward(self, F, z, ldj, reverse=False):
        
        if not reverse:
            z = z[:, self.permutation, :, :]
        else:
            z = z[:, self.permutation_inv, :, :]

        return z, ldj

    def InversePermute(self):
        inv_permute = Permute(len(self.permutation))
        inv_permute.permutation = self.permutation_inv
        inv_permute.permutation_inv = self.permutation
        return inv_permute


class Squeeze(HybridBlock):
    def __init__(self):
        super().__init__()

    def hybrid_forward(self, F, z, ldj, reverse=False):
        if not reverse:
            z = space_to_depth(z)
        else:
            z = depth_to_space(z)
        return z, ldj


class GenerativeFlow(HybridBlock):
    def __init__(self, n_channels, height, width, args):
        super().__init__()
        nnlayers = []
        nnlayers.append(Squeeze())
        n_channels *= 4
        height //= 2
        width //= 2

        self.layers = nn.HybridSequential()
       
        for level in range(args.n_levels):

            for i in range(args.n_flows):
                perm_layer = Permute(n_channels)
                nnlayers.append(perm_layer)
       
                nnlayers.append(
                    Coupling(n_channels, height, width, args))
              
            if level < args.n_levels - 1:
                if args.splitprior_type != 'none':
                    # Standard splitprior
                    factor_out = n_channels // 2
                    nnlayers.append(SplitPrior(n_channels, factor_out, height, width, args))
                   
                    n_channels = n_channels - factor_out

                nnlayers.append(Squeeze())
                
                n_channels *= 4
                height //= 2
                width //= 2
                
                
        self.layers.add(*nnlayers)
       
        self.z_size = (n_channels, height, width)

    def hybrid_forward(self, F, z, ldj, pys=(), ys=(), reverse=False):
        if not reverse:
            for l, layer in enumerate(self.layers):
                if isinstance(layer, (SplitPrior)):

                    print("split prior ==", SplitPrior)
                    py, y, z, ldj = layer(z, ldj)
                    pys += (py,)
                    ys += (y,)
                    print("pass")

                else:
                   # print("layer info ==", layer)
                    z, ldj = layer(z, ldj)
                   # print("pass")

        else:
   
            for l, layer in reversed(list(enumerate(self.layers))):
                if isinstance(layer, (SplitPrior)):
                    if len(ys) > 0:
                        z, ldj = layer.inverse(z, ldj, y=ys[-1])
                        # Pop last element
                        ys = ys[:-1]
                    else:
                        z, ldj = layer.inverse(z, ldj, y=None)

                else:
                    z, ldj = layer(z, ldj, reverse=True)

        print("return from the hell !!!")
        return z, ldj, pys, ys

    def decode(self, z, ldj, state, decode_fn):

        for l, layer in reversed(list(enumerate(self.layers))):
            if isinstance(layer, SplitPrior):
                z, ldj, state = layer.decode(z, ldj, state, decode_fn)

            else:
                z, ldj = layer(z, ldj, reverse=True)

        return z, ldj
