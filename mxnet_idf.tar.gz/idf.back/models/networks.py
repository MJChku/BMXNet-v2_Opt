"""
Collection of flow strategies
"""

from __future__ import print_function
from mxnet.gluon.block import HybridBlock
from mxnet.gluon import nn
import mxnet as mx

UNIT_TESTING = False


class Conv2dReLU(HybridBlock):
    def __init__(
            self, n_inputs, n_outputs, kernel_size=3, stride=1, padding=0,
            bias=True):
        super().__init__()
      
        self.nn = nn.HybridSequential(prefix='Conv2dReLU')
        
        self.nn.add(nn.QConv2D(in_channels = n_inputs, channels=n_outputs, kernel_size=kernel_size, padding=padding, bits=1))
        self.nn.add(nn.Activation('relu'))
   
    # F is hybrid parameter
    def hybrid_forward(self, F, x):    
        y = self.nn(x)
        return y


class ResidualBlock(HybridBlock):
    def __init__(self, n_channels, kernel, Conv2dAct):
        super().__init__()
 
        self.nn = nn.HybridSequential(prefix='')
        self.nn.add(Conv2dActd(n_channels, n_channels, kernel_size=kernel, padding=1))
        self.nn.add(nn.QCon2d(in_channels=n_channels, channels=n_channels, kernel_size=kernel, padding=1, bits=1))
        self.relu = nn.Activation('relu')

    def hybrid_forward(self, F, x):

        h = self.nn(x)
        h = F.relu(h + x)
        return h


class DenseLayer(HybridBlock):
    def __init__(self, args, n_inputs, growth, Conv2dAct):
        super().__init__()

        conv1x1 = Conv2dAct(
                n_inputs, n_inputs, kernel_size=1, stride=1,
                padding=0, bias=True)

        self.nn = nn.HybridSequential(prefix='')
        self.nn.add(conv1x1)
        self.nn.add(Conv2dAct(in_channels=n_inputs, channels=growth, kernel_size=3, padding=1,bias=True))

    def hybrid_forward(self,F,x):
        h = self.nn(x)
        h = F.concat(x,h, dim=1)
        return h


class DenseBlock(HybridBlock):
    def __init__(
            self, args, n_inputs, n_outputs, kernel, Conv2dAct):
        super().__init__()
        depth = args.densenet_depth

        future_growth = n_outputs - n_inputs
        self.nn = nn.HybridSequential(prefix='')
        for d in range(depth):
            growth = future_growth // (depth - d)
            self.nn.add(DenseLayer(args, n_inputs, growth, Conv2dAct))
            n_inputs += growth
            future_growth -= growth

    def hybrid_forward(self,F, x):
        return self.nn(x)


class Identity(HybridBlock):
    def __init__(self):
        super.__init__()

    def hybrid_forward(self, F, x):
        return x


class NN(HybridBlock):
    def __init__(
            self, args, c_in, c_out, height, width, nn_type, kernel=3):
        super().__init__()

        Conv2dAct = Conv2dReLU
        n_channels = args.n_channels

        self.nn = nn.HybridSequential(prefix='')
        
        
        if nn_type == 'shallow':
            if args.network1x1 == 'standard':
               conv1x1 = Conv2dAct(
                    n_channels, n_channels, kernel_size=1, stride=1,
                    padding=0, bias=False)
               self.nn.add(Conv2dAct(c_in, n_channels, kernel, padding=1))
               self.nn.add(conv1x1)
               self.nn.add(nn.QConv2D(in_channels=n_channels, channels=c_out, kernel_size=kernel, padding=1, bits=1))
            print("=====++++!!! =use shallow =============")
        elif nn_type == 'resnet':
             
            self.nn.add(Conv2dAct(c_in, n_channels, kernel, padding=1))
            self.nn.add(ResidualBlock(n_channels, kernel, Conv2dAct))
            self.nn.add(ResidualBlock(n_channels, kernel, Conv2dAct))
            self.nn.add(nn.QConv2D(in_channels=n_channels, channels=c_out, kernel_size=kernel, padding=1, bits=1))

        elif nn_type == 'densenet':
            
            self.nn.add(
                DenseBlock(
                    args=args,
                    n_inputs=c_in,
                    n_outputs=n_channels + c_in,
                    kernel=kernel,
                    Conv2dAct=Conv2dAct))
            self.nn.add(nn.QConv2D(in_channels=n_channels+c_in, channels=c_out, kernel_size=kernel, padding=1, bits=1))
        else:
            raise ValueError
        


    def hybrid_forward(self, F, x):
        return self.nn(x)
