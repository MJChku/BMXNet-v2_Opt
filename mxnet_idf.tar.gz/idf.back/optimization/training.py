from __future__ import print_function

from optimization.loss import calculate_loss
import numpy as np
import mxnet as mx
from mxnet import autograd
def train(epoch, train_loader, model, opt, args):
    
    train_loss = np.zeros(len(train_loader))
    train_bpd = np.zeros(len(train_loader))

    num_data = 0

    for batch_idx, (data, _) in enumerate(train_loader):
        data = data.as_in_context(args.ctx)
        data = mx.nd.reshape(data, shape=(-1, args.input_size[0], args.input_size[1],args.input_size[2]))
         
        with autograd.record():
             loss, bpd, bpd_per_prior, pz, z, pys, py, ldj = model(data)
             loss = mx.nd.mean(loss)
             loss.backward()
        bpd = mx.nd.mean(bpd)
        bpd_per_prior = [mx.nd.mean(i) for i in bpd_per_prior]

        print("loss", loss)
        train_loss[batch_idx] = loss
        train_bpd[batch_idx] = bpd

        ldj = nx.nd.mean(ldj) / np.prod(args.input_size) / np.log(2)

        opt.step()

        num_data += len(data)

    print('====> Epoch: {:3d} Average train loss: {:.4f}, average bpd: {:.4f}'.format(
        epoch, train_loss.sum() / len(train_loader), train_bpd.sum() / len(train_loader)))

    return train_loss, train_bpd


def evaluate(train_loader, val_loader, model,  args, testing=False, file=None, epoch=0):

    loss_type = 'bpd'

    def analyse(data_loader, plot=False):
        bpds = []
        batch_idx = 0
        for data, _ in data_loader:
                batch_idx += 1

                data = data.as_in_context(args.ctx)

                data =  mx.nd.reshape(data, shape=(-1, args.input_size[0], args.shape[1],args.input_size[2]))

                loss, batch_bpd, bpd_per_prior, pz, z, pys, ys, ldj = \
                    model(data)
                loss = mx.nd.mean(loss)
                batch_bpd = mx.nd.mean(batch_bpd)

                bpds.append(batch_bpd)

        bpd = mx.nd.mean(bpds)

        return bpd

    bpd_val = analyse(val_loader, plot=True)


    loss = bpd_val * np.prod(args.input_size) * np.log(2.)
    bpd = bpd_val

    print('====> Validation set loss: {:.4f}'.format(loss))
    print('====> Validation set bpd: {:.4f}'.format(bpd))
    return loss, bpd
