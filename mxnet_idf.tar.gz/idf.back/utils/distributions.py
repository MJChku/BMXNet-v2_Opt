from __future__ import print_function

import mxnet as mx

import numpy as np
import math

MIN_EPSILON = 1e-5
MAX_EPSILON = 1.-1e-5


PI = math.pi


def log_min_exp(a, b, epsilon=1e-8):
    """
    Computes the log of exp(a) - exp(b) in a (more) numerically stable fashion.
    Using:
     log(exp(a) - exp(b))
     c + log(exp(a-c) - exp(b-c))
     a + log(1 - exp(b-a))
    And note that we assume b < a always.
    """
    y = a + mx.nd.log(1 - mx.nd.exp(b - a) + epsilon)

    return y


def log_normal(x, mean, logvar):
    logp = -0.5 * logvar
    logp += -0.5 * np.log(2 * PI)
    logp += -0.5 * (x - mean) * (x - mean) / mx.nd.exp(logvar)
    return logp


def log_mixture_normal(x, mean, logvar, pi):
    x = mx.nd.reshape(x, shape=(x.shape[0], x.shape[1], x.shape[2], x.shape[3], 1))

    logp_mixtures = log_normal(x, mean, logvar)

    logp = mx.nd.log(mx.nd.sum(pi * mx.nd.exp(logp_mixtures), dim=-1) + 1e-8)

    return logp


def sample_normal(mean, logvar):
    y = mx.nd.random.normal(0,1, shape=(mean.shape))

    #y = mx.nd.randn_like(mean)

    x = mx.nd.exp(0.5 * logvar) * y + mean

    return x

'''
def sample_mixture_normal(mean, logvar, pi):
    b, c, h, w, n_mixtures = tuple(map(int, pi.shape))
    pi =mx.nd.reshape(pi, shape=(b * c * h * w, n_mixtures))
    sampled_pi = torch.multinomial(pi, num_samples=1).view(-1)

    # Select mixture params
    mean = mean.view(b * c * h * w, n_mixtures)
    mean = mean[torch.arange(b*c*h*w), sampled_pi].view(b, c, h, w)
    logvar = logvar.view(b * c * h * w, n_mixtures)
    logvar = logvar[torch.arange(b*c*h*w), sampled_pi].view(b, c, h, w)

    y = sample_normal(mean, logvar)

    return y
'''

def log_logistic(x, mean, logscale):
    """
       pdf = sigma([x - mean] / scale) * [1 - sigma(...)] * 1/scale
    """
    scale = mx.nd.exp(logscale)

    u = (x - mean) / scale

    logp = mx.nd.log(mx.nd.sigmoid(u)) + mx.nd.log(mx.nd.sigmoid(-u)) - logscale

    return logp


def sample_logistic(mean, logscale):
    y = mx.nd.random.uniform(0,1,shape=(mean.shape))
    #y = torch.rand_like(mean)

    x = mx.nd.exp(logscale) * mx.nd.log(y / (1 - y)) + mean

    return x


def log_discretized_logistic(x, mean, logscale, inverse_bin_width):
    scale = mx.nd.exp(logscale)

    logp = log_min_exp(
        mx.nd.log(mx.nd.sigmoid((x + 0.5 / inverse_bin_width - mean) / scale)),
        mx.nd.log(mx.nd.sigmoid((x - 0.5 / inverse_bin_width - mean) / scale)))

    return logp


def discretized_logistic_cdf(x, mean, logscale, inverse_bin_width):
    scale = mx.nd.exp(logscale)

    cdf = mx.nd.sigmoid((x + 0.5 / inverse_bin_width - mean) / scale)

    return cdf


def sample_discretized_logistic(mean, logscale, inverse_bin_width):
    x = sample_logistic(mean, logscale)

    x = mx.nd.round(x * inverse_bin_width) / inverse_bin_width
    return x

"""
def normal_cdf(value, loc, std):
        return 0.5 * (1 + torch.erf((value - loc) * std.reciprocal() / math.sqrt(2)))


def log_discretized_normal(x, mean, logvar, inverse_bin_width):
    std = torch.exp(0.5 * logvar)
    log_p = torch.log(normal_cdf(x + 0.5 / inverse_bin_width, mean, std) - normal_cdf(x - 0.5 / inverse_bin_width, mean, std) + 1e-7)

    return log_p


def log_mixture_discretized_normal(x, mean, logvar, pi, inverse_bin_width):
    std = torch.exp(0.5 * logvar)

    x = x.view(x.size(0), x.size(1), x.size(2), x.size(3), 1)

    p = normal_cdf(x + 0.5 / inverse_bin_width, mean, std) - normal_cdf(x - 0.5 / inverse_bin_width, mean, std)

    p = torch.sum(p * pi, dim=-1)

    logp = torch.log(p + 1e-8)

    return logp


def sample_discretized_normal(mean, logvar, inverse_bin_width):
    y = mx.nd.random.normal(0,1,shape=(mean.shape))

    #y = torch.randn_like(mean)

    x = mx.nd.exp(0.5 * logvar) * y + mean

    x = mx.nd.round(x * inverse_bin_width) / inverse_bin_width

    return x
"""

def log_mixture_discretized_logistic(x, mean, logscale, pi, inverse_bin_width):
    scale = mx.nd.exp(logscale)

    x = mx.nd.reshape( x, shape=(x.shape[0], x.shape[1], x.shape[2], x.shape[3], 1))

    p = mx.nd.sigmoid((x + 0.5 / inverse_bin_width - mean) / scale) \
        - mx.nd.sigmoid((x - 0.5 / inverse_bin_width - mean) / scale)

    p = mx.nd.sum(p * pi, dim=-1)

    logp = mx.nd.log(p + 1e-8)

    return logp


def mixture_discretized_logistic_cdf(x, mean, logscale, pi, inverse_bin_width):
    scale = torch.exp(logscale)

    x = x[..., None]

    cdfs = mx.nd.sigmoid((x + 0.5 / inverse_bin_width - mean) / scale)

    cdf = mx.nd.sum(cdfs * pi, dim=-1)

    return cdf


def sample_mixture_discretized_logistic(mean, logs, pi, inverse_bin_width):
    # Sample mixtures
    b, c, h, w, n_mixtures = tuple(map(int, pi.size()))
    pi =mx.nd.reshape(pi, shape= (b * c * h * w, n_mixtures))

    sampled_pi = mx.nd.sample_multinomial(pi, shape=(1)).reshape(-1)
    #torch.multinomial(pi, num_samples=1).view(-1)

    # Select mixture params
    mean = mean.reshape(b * c * h * w, n_mixtures)
    mean = mean[mx.nd.arange(b*c*h*w), sampled_pi].view(b, c, h, w)
    logs = logs.reshape(b * c * h * w, n_mixtures)
    logs = logs[mx.nd.arange(b*c*h*w), sampled_pi].view(b, c, h, w)
  
  
    y = mx.nd.random.uniform(0,1,shape=(mean.shape))
    #y = torch.rand_like(mean)
    x = mx.nd.exp(logs) * mx.nd.log(y / (1 - y)) + mean

    x = mx.nd.round(x * inverse_bin_width) / inverse_bin_width

    return x

"""
def log_multinomial(logits, targets):
    return -F.cross_entropy(logits, targets, reduction='none')


def sample_multinomial(logits):
    b, n_categories, c, h, w = logits.size()
    logits = logits.permute(0, 2, 3, 4, 1)
    p = F.softmax(logits, dim=-1)
    p = p.view(b * c * h * w, n_categories)
    x = torch.multinomial(p, num_samples=1).view(b, c, h, w)
    return x
"""
