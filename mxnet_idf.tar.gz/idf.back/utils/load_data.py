from mxnet import gluon
import mxnet.gluon.data.vision.transforms as transforms

class scale255(gluon.HybridBlock):
    def __init__(self):
        super().__init__()

    def hybrid_forward(self,F,x):
        return  x*255.

def load_cifar10(args, **kwargs):
    # set args
    args.input_size = [3, 32, 32]
    args.input_type = 'continuous'
    args.dynamic_binarization = False

    transform_train = transforms.Compose([
        transforms.ToTensor(),
        scale255()
    ]
   )
    transform_test = transforms.Compose([
        transforms.ToTensor(),
        scale255()
    ]
   )
    train_loader = gluon.data.DataLoader(
    gluon.data.vision.CIFAR10(train=True).transform_first(transform_train),
        batch_size=args.batch_size, shuffle=True, last_batch='discard', num_workers=4)

# Set train=False for validation data
    val_loader = gluon.data.DataLoader(
    gluon.data.vision.CIFAR10(train=False).transform_first(transform_test),
        batch_size=args.batch_size, shuffle=False, num_workers=4)

    return train_loader, val_loader, val_loader, args




def load_dataset(args, **kwargs):

    if args.dataset == 'cifar10':
        train_loader, val_loader, test_loader, args = load_cifar10(args, **kwargs)

    return train_loader, val_loader, test_loader, args

