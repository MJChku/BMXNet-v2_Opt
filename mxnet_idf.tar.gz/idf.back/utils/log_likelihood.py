from __future__ import print_function


from mxnet import gluon

import os
import os.path
from os.path import join


def load_cifar10(args, **kwargs):
    # set args
    args.input_size = [3, 32, 32]
    args.input_type = 'continuous'
    args.dynamic_binarization = False


    train_loader = gluon.data.DataLoader(
            gluon.data.vision.CIFAR10(train=True).transform_first(transform_train), batch_size=batch_size, shuffle=True, last_batch='discard', num_workers=4
            )

    val_loader = gluon.data.DataLoader(
            gluon.data.vision.CIFAR10(train=False).transform_first(transform_train), batch_size=batch_size, shuffle=False, last_batch='discard', num_workers=4
            )


    return train_loader, val_loader, val_loader, args



def load_dataset(args, **kwargs):

    if args.dataset == 'cifar10':
        train_loader, val_loader, test_loader, args = load_cifar10(args, **kwargs)

    return train_loader, val_loader, test_loader, args
